# KIVO NEST — Telegram Mini App

> Biz ko'p mahsulot sotmaymiz. Biz eng yaxshi mahsulotlarni tanlaymiz.

To'liq stack: **Python (aiogram 3 + FastAPI)** backend, **vanilla JS** Mini App frontend, SQLite (aiosqlite).

## Loyihada nima bor

- `backend/` — FastAPI API + aiogram bot bitta process ichida ishlaydi
  - `main.py` — API endpointlar + frontend'ni serve qiladi
  - `bot.py` — `/start` va **admin panel butunlay shu yerda**: yangi buyurtma kelganda admin chatga karta yuboriladi, tugmalar (✅ Confirm → 📦 Packed → 🚚 Shipped → ✅ Delivered) bosilganda mijozga avtomatik xabar ketadi
  - `models.py`, `database.py`, `schemas.py`, `auth.py`, `seed.py`
- `frontend/` — Mini App (HTML/CSS/JS, hash-router, Telegram WebApp SDK)
  - Welcome → Home → Category → Product → Cart → Checkout → Success
  - Bottom nav: Home / Search / Cart / Favorites / Profile
  - AI Search, KIVO Score, Essential/Recommended/Premium Compare

## O'rnatish

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

`.env` faylini to'ldiring:

| O'zgaruvchi | Qayerdan olinadi |
|---|---|
| `BOT_TOKEN` | @BotFather → `/newbot` |
| `ADMIN_CHAT_ID` | Botga `/start` yozing, keyin `https://api.telegram.org/bot<TOKEN>/getUpdates` ochib `chat.id` ni oling |
| `WEBAPP_URL` | Mini App qayerda ishlashi (pastga qarang) |
| `ANTHROPIC_API_KEY` | *(ixtiyoriy)* — bo'lsa AI Search Claude orqali so'rovni tushunadi, bo'lmasa oddiy kalit so'z bo'yicha qidiradi |

## Ishga tushirish (lokal)

```bash
cd backend
uvicorn main:app --reload --port 8000
```

Birinchi ishga tushganda SQLite fayl (`kivo_nest.db`) avtomatik yaratiladi va demo mahsulotlar (`seed.py`) bilan to'ldiriladi — har category uchun Essential/Recommended/Premium.

Telegram **haqiqiy Mini App uchun HTTPS talab qiladi**. Lokal test uchun:

```bash
ngrok http 8000
```

Chiqqan `https://xxxx.ngrok-free.app` manzilini `.env`dagi `WEBAPP_URL`ga qo'ying va serverni qayta ishga tushiring. Xuddi shu URL'ni @BotFather'da ham sozlang: `/mybots` → botingiz → `Bot Settings` → `Menu Button` → shu URL.

## Rasmlar

`seed.py` ichida hozircha placeholder (`picsum.photos`) rasmlar bor — bular faqat maketni ko'rish uchun. Ishlab chiqarishga chiqarishdan oldin `Product.image_urls`ni haqiqiy mahsulot fotosuratlari bilan almashtiring (masalan, o'z CDN yoki Telegram file_id orqali).

## Admin oqimi qanday ishlaydi

Alohida admin sahifa yo'q — bu ataylab shunday, chunki spetsifikatsiyada "Admin Telegram ichida ko'radi" deyilgan:

1. Mijoz checkout qilganda backend `notify_admin_new_order()` chaqiradi
2. Admin chatga buyurtma kartasi + tugma keladi
3. Tugma bosilganda: DB yangilanadi, karta matni tahrirlanadi, mijozga avtomatik xabar ketadi

## Kengaytirish g'oyalari

- `KivoScore` hisoblashni qo'lda emas, admin panel orqali tahrirlash imkonini qo'shish
- Promo-kod validatsiyasini backend'da haqiqiy qilish (hozir faqat UI maydon)
- Buyurtmalar tarixi sahifasini Profile ichida to'liq ochish
- Rasmlarni Telegram file_id orqali saqlab, tashqi CDN'siz ishlash
